package e.flagemac.becausemathishard.recallclasses

import android.arch.persistence.room.Room
import android.arch.persistence.room.RoomDatabase
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import e.flagemac.becausemathishard.dataclasses.Tip
import e.flagemac.becausemathishard.lametipclasses.LameTipActivity
import e.flagemac.becausemathishard.R
import e.flagemac.becausemathishard.dataclasses.AppDB
import e.flagemac.becausemathishard.tipexperience.ExperienceController
import kotlinx.android.synthetic.main.activity_navigation_drawer.*
import kotlinx.android.synthetic.main.app_bar_navigation_drawer.*
import kotlinx.android.synthetic.main.recent_tip_item.*
import kotlinx.android.synthetic.main.recent_tips_home.*
import java.util.*
import kotlin.collections.ArrayList

/**
 * Created by FlageMac on 4/24/18.
 */
class RecallActivity: AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    var listOfRecentTips: ArrayList<Tip> = ArrayList()
    var drawer: DrawerLayout? = null
    var toggle : ActionBarDrawerToggle? = null
    var navView : NavigationView? = null

    var listAdapter: TipAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navigation_drawer)
        setSupportActionBar(toolbar)

        RecallActivity.db = Room.databaseBuilder(applicationContext, AppDB::class.java, "tip-database").allowMainThreadQueries().build()

        val toggle = ActionBarDrawerToggle(
                this, drawer_layout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawer_layout.addDrawerListener(toggle)
        toggle.syncState()

        Toast.makeText(this@RecallActivity, "nav_view.isActivated", Toast.LENGTH_SHORT).show()
        nav_view.setNavigationItemSelectedListener(this)
        // this try will attempt to retrieve a list of 5 most recent activities
        checkTime()

        defaultTips()

        listAdapter = TipAdapter(this, listOfRecentTips)
        recent_tips.adapter = listAdapter

        button_special.setOnClickListener {
            resetTips()
            listAdapter!!.notifyDataSetChanged()
        }
    }

    private fun defaultTips() {
        val d1 = Calendar.getInstance()
        d1.set(2018, 3, 17)
        val d2 = Calendar.getInstance()
        d2.set(2018, 3, 17)
        val d3 = Calendar.getInstance()
        d3.set(2018, 3, 1)
        val d4 = Calendar.getInstance()
        d4.set(2018, 4, 20)
        val d5 = Calendar.getInstance()
        d5.set(2018, 1, 24)
        val d6 = Calendar.getInstance()
        d6.set(2018, 3, 30)



        val tip1 = Tip(0, 135.90, 0.18, d1, local1)
        val tip2 = Tip(1,75.25,0.20, d2, local2)
        val tip3 = Tip(2,82.91, 0.14, d3, local3)
        val tip4 = Tip(3,50.23, 0.21, d4, local4)
        val tip5 = Tip(4,98.26, 0.17, d5, local5)
        val tip6 = Tip(5,123.45, 0.08, d6, local1)

        listOfRecentTips.add(tip1)
        listOfRecentTips.add(tip2)
        listOfRecentTips.add(tip3)
        listOfRecentTips.add(tip4)
        listOfRecentTips.add(tip5)
        listOfRecentTips.add(tip6)

        for (tip in listOfRecentTips) {
            RecallActivity.db?.tipDao()?.insertTip(tip)
        }
    }

    override fun onResume() {
        super.onResume()
        loadRecents()
        checkTime()

        listAdapter!!.notifyDataSetChanged()

    }

    override fun onBackPressed() {
        if (drawer_layout.isDrawerOpen(GravityCompat.START)) {
            drawer_layout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        var i: Intent? = null

        when (item.itemId) {

            R.id.nav_new_lame_tip -> {
                i = Intent(this@RecallActivity, LameTipActivity::class.java)
            }

            R.id.nav_new_experience -> {
                i = Intent(this@RecallActivity, ExperienceController::class.java)
            }

            else -> {
                Toast.makeText(this@RecallActivity, "Clicked", Toast.LENGTH_SHORT).show()
            }
        }

        drawer_layout.closeDrawer(GravityCompat.START)

        //startActivity(i)
        startActivityForResult(i, 1)
        return true
    }

    private fun loadRecents() {
        listOfRecentTips = ArrayList()
        val hold = RecallActivity.db!!.tipDao().getAllTips()

        hold.forEach {
            listOfRecentTips.add(it)
        }
    }

    private fun openLameTip(context: Context)  {

        val i = Intent(context, LameTipActivity::class.java)
        startActivity(i)

    }

    private fun resetTips() {

        RecallActivity.db!!.tipDao().deleteAll()

        defaultTips()

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (resultCode) {

            420 -> {
                val mc = data?.extras?.getDouble("mealcost")
                val per = data?.extras?.getDouble("percent")
                val time = data?.extras?.getLong("time")
                val lat = data?.extras?.getDouble("latitude")
                val long = data?.extras?.getDouble("longitude")

                val t = Tip(0, mc!!, per!!, time!!, lat!!, long!!)

                RecallActivity.db?.tipDao()?.insertTip(t)
                listOfRecentTips.add(t)
                listAdapter!!.notifyDataSetChanged()
            }
        }
    }

    fun checkTime() {

        val date = Calendar.getInstance()
        val hour = date.get(Calendar.HOUR_OF_DAY)
        Log.i("hr", "$hour")
        // if morning (before 11am) : Return  Breakfast Time
        when (hour) {
            1,2,3,4,5,6,7,8,9,10 -> {
                displayMealTime.text = getString(R.string.breakfast_time)
            }
            11,12,13,14,15 -> {
                displayMealTime.text = getString(R.string.lunch_time)
            }
            16,17, 18,19, 20 -> {
                displayMealTime.text = getString(R.string.supper_time)
            }
            21,22,23,0 -> {
                displayMealTime.text = getString(R.string.midnight_snack)
            }
        }

    }

    inner class TipAdapter(cntxt: Context, l: ArrayList<Tip>) : BaseAdapter() {

        val list: ArrayList<Tip> = l
        val context: Context? = cntxt

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View?
            val th: TipHolder

            if (convertView == null) {
                view = layoutInflater.inflate(R.layout.recent_tip_item, parent, false)
                th = TipHolder(view)
                view.tag = th
                Log.i("JSA", "set Tag for ViewHolder, position: " + position)
            } else {
                view = convertView
                th = view.tag as TipHolder
            }

            th.cost.text = list[position].priceToString()
            th.date.text = list[position].dateToString()
            th.tip.text = list[position].tipToString()
            if (list[position].latitude == 0.0 && list[position].longitude == 0.0) {
                th.location.text = "Location Unavailable"
            }
            else {
                th.location.text = list[position].locationToString()
            }
            val i = list[position].tip

            when (true) {
                (i >= 0.0 && i < 0.10) -> {
                    th.card.background = getDrawable(R.drawable.bad_background_border)
                }
                (i >= 0.1 && i < 0.15) -> {
                    th.card.background = getDrawable(R.drawable.meh_background_border)
                }
                (i >= 0.15) -> {
                    th.card.background = getDrawable(R.drawable.good_background_border)
                }
            }

            return view!!
        }

        override fun getItem(position: Int): Any {
            return list[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return list.size
        }

    }

    private class TipHolder(view: View) {

        val date: TextView = view.findViewById(R.id.tip_display_date) as TextView
        val cost: TextView = view.findViewById(R.id.tip_display_cost) as TextView
        val tip: TextView = view.findViewById(R.id.tip_display_tip) as TextView
        val location: TextView = view.findViewById(R.id.tip_display_location) as TextView
        val card: RelativeLayout = view.findViewById(R.id.recent_tip) as RelativeLayout

        fun setTextColor(int: Int) {
            date.setTextColor(int)
            cost.setTextColor(int)
            tip.setTextColor(int)
            location.setTextColor(int)
        }

    }

    companion object {

        fun setLocal(lat: Double, long: Double) : Location{
            val l = Location("")
            l.latitude = lat
            l.longitude = long

            return l
        }


        var local1 : Location = setLocal(39.758696,-105.057510)
        var local2 : Location = setLocal(39.762786,-105.037511)
        var local3 : Location = setLocal(39.619226,-104.888742)
        var local4 : Location = setLocal(39.582323,-104.876397)
        var local5 : Location = setLocal(39.590006,-104.865325)

        var db : AppDB? = null

    }

}


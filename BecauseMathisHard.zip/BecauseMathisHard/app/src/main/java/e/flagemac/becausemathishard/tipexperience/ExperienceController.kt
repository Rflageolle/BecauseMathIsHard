package e.flagemac.becausemathishard.tipexperience

import android.Manifest
import android.app.ActivityManager
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.Image
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.support.transition.AutoTransition
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.*
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.places.*
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import e.flagemac.becausemathishard.R
import e.flagemac.becausemathishard.dataclasses.Tip
import e.flagemac.becausemathishard.recallclasses.RecallActivity
import java.io.IOException
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * Created by FlageMac on 5/5/18.
 */
class ExperienceController : AppCompatActivity(), SwipeInterface{
    /**
     *   This class controls the Tip Experience calculator, it uses the main_view_tipexperience layout file,
     *   which has three sections:
     *
     *      1) The Title component (tipexperience_title_component) - which will be populated with the fragment_title_component layout file
     *
     *      2) The Content component (tipexperience_content) - which will be populated dynamically depending on the users current category
     *
     *          A) For the beginning of the tip (fragment_infoscreen)
     *
     *              - populate date
     *
     *              - populate if permission the user's location
     *
     *          B) For a category (fragment_category)
     *
     *              - need to a button listener for the image which displays the list view contaning tips for how to score.
     *
     *              - need a listener for the check boxes
     *
     *          C) For after the categories (fragment_get_meal_cost)
     *
     *              - need to read in the user's meal cost
     *
     *          D) Finally (Fragment_recipt)
     *
     *              - need to populate the full receipt
     *
     *     3) The Bottom component (tipexperience_bottom_component)
     *
     *          A) For the beginning of the tip (fragment_progress_component)
     *
     *          B) For the Categories (fragment_progress_component)
     *
     *          C) For after the categories (fragment_button_component)
     *
     *              - Button listener which reads in the user's meal cost
     *
     *          D) For the receipt (fragment_button_component)
     *
     *              - Button listener which creates Tip object and uploads it to the room database
     *              - and if tip is good enough have it ask user if they would like to write a review on Yelp
     *
     *    Also needed is the ability to fill these categories (only allow going back through the categories) with the correct information and
     *    states that they were in before.  (user goes back from humor to speed need to be able to show them what was selected)
     *
     *    Also needed is getting the users location and sending it to the Places API. or if the user would rather have it directly enter the name
     *    of the restaurant
     *
     *    need to also be able to load to the last known information if app crashes.
     *
     */


    /**
     *  Main Tip Variables
     */

        var cal: Calendar? = null
        var mLocation: Location? = null
        var locationManager : LocationManager? = null
        var latitude: Double? = null
        var longitude: Double? = null

        var useLocation: Boolean = true
        var locationObtained: Boolean = false
        var currentCategory: Int = 0

        var numberOfCategories = 5
        var scores: Array<Int>? = null

        var currentView: View? = null
        var mainViewHolder: MainViewHolder? = null

        var list : Array<Category>? = null

        var locations: ArrayList<Location>? = null

        var defaultTip = 0.2
        var tipPercent: Double = 0.0
        var mealCost: Double = 0.0

        var moveOn = false

        var currentPlace: Place? = null
        var mPlaceDetector: PlaceDetectionClient? = null
        var gdc: GeoDataClient? = null

        var locationGrabbed = false

    init {

        start.setType(0)
        finish.setType(2)
        receipt.setType(3)
        cat1.setType(1)
        cat2.setType(1)
        cat3.setType(1)
        cat4.setType(1)
        cat5.setType(1)

        list = arrayOf(start, cat1, cat2, cat3, cat4, cat5, finish, receipt)
        scores = arrayOf(0,0,0,0,0)

        cal = Calendar.getInstance(TimeZone.getDefault())

        // One thing I think would bee cool to try is if they dont want me to use their location  i could have them manually enter the Restaurant name.

    }

    /**
     *  ------------------------------  ___________________________________________________________
     *  ACTIVITY LIFECYLE - FUNCTIONS | -----------------------------------------------------------
     *  ------------------------------
     */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val mv = View.inflate(this@ExperienceController, R.layout.main_view_tipexperience, null)
        setContentView(mv)

        gdc = Places.getGeoDataClient(this@ExperienceController)
        mPlaceDetector = Places.getPlaceDetectionClient(this@ExperienceController)

        val swipeInterface = ActivitySwipeDetector(this, this)
        mv.setOnTouchListener(swipeInterface)
        mainViewHolder = MainViewHolder(mv)
        mainViewHolder!!.setTitleView()
        setUpContentView(list!![currentCategory])

        // mainViewHolder!!.contentFrameLayout.setOnTouchListener(swipeInterface)

    }

    override fun onStart() {
        super.onStart()

        useLocation = ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    /**
     *      END LIFECYCLE FUNCTIONS
     */

    /**
     *   Application Functions
     */

    fun getLocation(c: Context) {
        val locationManager = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val enabledGPS = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val enabledWIFI = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        val criteria = Criteria()
        criteria.accuracy = Criteria.ACCURACY_FINE
        criteria.horizontalAccuracy = Criteria.ACCURACY_HIGH
        criteria.verticalAccuracy = Criteria.ACCURACY_HIGH
        criteria.isSpeedRequired = false
        criteria.isCostAllowed = true
        criteria.isBearingRequired = false
        val provider = locationManager.getBestProvider(criteria, false)
        var location: Location? = null


        if (useLocation) {
            try {
                locationManager.requestSingleUpdate(provider, mLocationListener(), null)
            } catch (ex: SecurityException) {
                Toast.makeText(this@ExperienceController, "${ex.toString()} + is why it aint working", Toast.LENGTH_LONG).show()
            }
        }

        else {
            val builder = AlertDialog.Builder(this@ExperienceController)
            builder.setMessage("Would you like to change Location Permission?")
            builder.setTitle("ALLOW LOCATION!")
            builder.setPositiveButton("YES") { dialog, which ->
                val locationIntent = Intent()
                locationIntent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                val uri = Uri.fromParts("package", packageName, null)
                startActivity(locationIntent)
            }
            builder.setNegativeButton("NO") { dialog, which ->
                useLocation = false
                dialog!!.dismiss()
            }
            builder.create()
        }
    }

    fun getPlace() {

        val canGet = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val second = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (!canGet || second) {
            val result = mPlaceDetector!!.getCurrentPlace(null)
            var smallest = 0f
            var toKeep: Place? = null
//            result.addOnCompleteListener { p0 ->
//                val responses: PlaceLikelihoodBufferResponse = p0.result
//                for (place in responses) {
//                    Log.i("Places: ", "Place ${place.place.name} has likelihood: ${place.likelihood}")
//                    if (place.likelihood > smallest) {
//                        smallest = place.likelihood
//                        toKeep = place.place
//                    }
//                }
//                responses.release()
//                currentPlace = toKeep
//                Toast.makeText(this, toKeep!!.address, Toast.LENGTH_LONG).show()
//            }
            result.addOnCompleteListener(object: OnCompleteListener<PlaceLikelihoodBufferResponse> {
                override fun onComplete(task: Task<PlaceLikelihoodBufferResponse>) {
                    try {
                        if (task.isSuccessful && task.result != null) {
                            var likelyPlaces: PlaceLikelihoodBufferResponse = task.result
                            for (place in likelyPlaces) {
                                Log.i("Places: ", "Place ${place.place.name} has likelihood: ${place.likelihood}")
                                if (place.likelihood > smallest) {
                                    smallest = place.likelihood
                                    toKeep = place.place
                                }
                            }
                            likelyPlaces.release()
                            currentPlace = toKeep
                            Toast.makeText(this@ExperienceController, currentPlace?.address, Toast.LENGTH_LONG).show()
                        } else {
                            Log.i("Places API: ", "Exception: ${task.exception.toString()}")
                        }
                    } catch (e: ApiException) {
                        Log.i("Places API: ", e.printStackTrace().toString())
                    }
                }

            })
        }
        else {
            val builder = AlertDialog.Builder(this@ExperienceController)
            builder.setMessage("Would you like to change Location Permission?")
            builder.setTitle("ALLOW LOCATION!")
            builder.setPositiveButton("YES") { dialog, which ->
                val locationIntent = Intent()
                locationIntent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                val uri = Uri.fromParts("package", packageName, null)
                startActivity(locationIntent)
            }
            builder.setNegativeButton("NO") { dialog, which ->
                useLocation = false
                dialog!!.dismiss()
            }
            builder.create()
        }

    }

    fun setUpContentView(cc: Category) {
        when (cc.t) {
            Type.START -> {
                currentView = View.inflate(this@ExperienceController, R.layout.fragment_infoscreen, null)
                val btmV = View.inflate(this@ExperienceController, R.layout.fragment_progress_component, null)
                mainViewHolder!!.setContentView(currentView!!)
                mainViewHolder!!.setBottomView(btmV)

                moveOn = true
                getPlace()

                val sh = StartHolder(currentView!!)
                sh.setDate(cal!!)
                sh.setLocation(useLocation)

                val ph = ProgressHolder(btmV)
                ph.setProgress(currentCategory)
                ph.setRunningTipPercent(getCurrentTipPercent())

            }
            Type.CATEGORY -> {
                currentView = View.inflate(this@ExperienceController, R.layout.fragment_category, null)
                val btmV = View.inflate(this@ExperienceController, R.layout.fragment_progress_component, null)
                mainViewHolder!!.setContentView(currentView!!)
                mainViewHolder!!.setBottomView(btmV)

                moveOn = false

                val ch = CategoryHolder(currentView!!)
                ch.setTitle(list!![currentCategory].title)
                ch.setImage(setI(list!![currentCategory]))
                ch.setChecks(scores!![currentCategory - 1])

                ch.score.setOnCheckedChangeListener { group, checkedId ->
                    when (checkedId) {
                        R.id.checkbox_1 -> {
                            //Toast.makeText(this, checkedId.toString() + "$checkedId", Toast.LENGTH_SHORT).show()
                            Log.i("CheckedBox::"," 1")
                            scores!![currentCategory - 1] = 1
                            moveOn = true
                        }
                        R.id.checkbox_2 -> {
                            //Toast.makeText(this, checkedId.toString() + "$checkedId", Toast.LENGTH_SHORT).show()
                            Log.i("CheckedBox::"," 2")
                            scores!![currentCategory - 1] = 2
                            moveOn = true
                        }
                        R.id.checkbox_3 -> {
                            //Toast.makeText(this, checkedId.toString() + "$checkedId", Toast.LENGTH_SHORT).show()
                            Log.i("CheckedBox::"," 3")
                            scores!![currentCategory - 1] = 3
                            moveOn = true
                        }
                        R.id.checkbox_4 -> {
                            //Toast.makeText(this, checkedId.toString() + "$checkedId", Toast.LENGTH_SHORT).show()
                            Log.i("CheckedBox::"," 4")
                            scores!![currentCategory - 1] = 4
                            moveOn = true
                        }
                        R.id.checkbox_5 -> {
                            //Toast.makeText(this, checkedId.toString() + "$checkedId", Toast.LENGTH_SHORT).show()
                            Log.i("CheckedBox::"," 5")
                            scores!![currentCategory - 1] = 5
                            moveOn = true
                        }
                    }
                }

                val ph = ProgressHolder(btmV)
                ph.setProgress(currentCategory)
                //ph.setRunningTipPercent(getCurrentTipPercent())
                ph.setRunningScore(getRunningScore(), numberOfCategories)
            }
            Type.FINISH -> {
                currentView = View.inflate(this@ExperienceController, R.layout.fragment_get_meal_cost, null)
                val btmV = View.inflate(this@ExperienceController, R.layout.fragment_button_component, null)
                mainViewHolder!!.setContentView(currentView!!)
                mainViewHolder!!.setBottomView(btmV)

                moveOn = false

                val fh = EndCategoriesHolder(currentView!!)
                fh.setTipPercent(getCurrentTipPercent())

                val bh = ButtonHolder(btmV)
                bh.button.setOnClickListener {
                    try {
                        val str = fh.mealCost.text.toString()
                        str.trim()

                        if (!str.isEmpty()) {
                            Log.i("Meal Cost = ", str)
                            mealCost = str.toDouble()

                            currentCategory++
                            setUpContentView(list!![currentCategory])

                        }
                    }catch (e: IOException) {
                        e.printStackTrace()
                    }

                }

            }
            Type.RECEIPT -> {
                currentView = View.inflate(this@ExperienceController, R.layout.fragement_recipt, null)
                val btmV = View.inflate(this@ExperienceController, R.layout.fragment_button_component, null)
                mainViewHolder!!.setContentView(currentView!!)
                mainViewHolder!!.setBottomView(btmV)

                val fTipPercent = getCurrentTipPercent()
                val tipValue = mealCost * fTipPercent
                val finalCost = mealCost + tipValue

                val rh = ReciptHolder(currentView!!)
                rh.setDate(cal!!)
                rh.setSubTotal(mealCost)
                rh.setTipValue(tipValue)
                rh.setFinalCost(finalCost)

                val bh = ButtonHolder(btmV)
                bh.button.setOnClickListener {
                    var lat: Double = 0.0
                    var long: Double = 0.0
                    if (locationGrabbed) {
                        lat = latitude!!
                        long = longitude!!
                    }

                    val int = Intent()
                    int.putExtra("mealcost", mealCost)
                    int.putExtra("percent", tipPercent)
                    int.putExtra("time", cal!!.time.time)
                    int.putExtra("longitude", long)
                    int.putExtra("latitude", lat)
                    setResult(420, int)

                    //val t = Tip(0, mealCost, tipPercent, cal!!.time.time, long, lat)

                    //RecallActivity.db?.tipDao()?.insertTip(t)
                    super.finish()
                }
            }
        }

    }

    private fun getRunningScore(): Int {
        var sum = 0

        val current =  currentCategory - 1

        for (x in 0..current) {
            sum += scores!![x]
        }

        return sum
    }

    fun dateToString(calendar: Calendar) : String {
        val y = calendar.get(Calendar.YEAR)
        val m = calendar.get(Calendar.MONTH)
        val d = calendar.get(Calendar.DAY_OF_MONTH)

        return String.format("%d/%d/%d", m, d, y)
    }

    fun getCurrentTipPercent() : Double {
        if (list!![currentCategory].t == Type.RECEIPT || list!![currentCategory].t == Type.FINISH) {
            var sum = 0
            val total = numberOfCategories * numberOfCategories
            var rest = 0
            var current =  currentCategory - 1

            for (x in 0 until scores!!.size) {
                sum += scores!![x]
            }

            val result = when (sum) {
                0, 1, 2, 3, 4, 5 -> Result.SHIT
                6, 7, 8, 9, 10 -> Result.MEH
                11, 12, 13, 14, 15 -> Result.OKAY
                16, 17, 18, 19, 20 -> Result.GOOD
                else -> Result.GREAT
            }

            return when (result) {
                Result.SHIT     -> {
                    defaultTip - 0.15
                }
                Result.MEH      -> {
                    defaultTip - 0.1
                }
                Result.OKAY     -> {
                    defaultTip - 0.05
                }
                Result.GOOD     -> {
                    defaultTip
                }
                Result.GREAT    -> {
                    defaultTip + 0.05
                }
            }
        }
        else { return 0.2 }
    }



    fun alredyHaveScore() : Boolean {
        if (currentCategory in 1..numberOfCategories) {
            if (scores!![currentCategory] != 0) {
                return true
            }
            else { return false }
        }
        else { return false }
    }

    private fun setI(cat: Category) : Drawable {

        val d: Drawable

        when (cat.title) {

            "Speed" -> {
                d = getDrawable(R.drawable.speed_icon)
            }
            "Accuracy" -> {
                d = getDrawable(R.drawable.accuracy_icon)
            }
            "Humor" -> {
                d = getDrawable(R.drawable.humor_icon)
            }
            "Food" -> {
                d = getDrawable(R.drawable.food_icon)
            }
            "Politeness" -> {
                d = getDrawable(R.drawable.politness_icon)
            }

            else -> {
                d = getDrawable(R.drawable.ic_menu_gallery)
            }

        }

        return d
    }

    override fun right2left(v: View) {

        // display next Category
        val transition = AutoTransition()
        transition.duration = 1000

        if (currentCategory < 8 && moveOn) {
            currentCategory++

            setUpContentView(list!![currentCategory])

        }

    }

    override fun left2right(v: View) {

        // display previous Category
        val swipe_layout = this.findViewById<RelativeLayout>(R.id.swipe_layout)
        val transition = AutoTransition()
        transition.duration = 1000

        // if no score toast to tell them it is needed

        if (currentCategory > 2) {
            currentCategory--

            setUpContentView(list!![currentCategory])

        }

    }


    /**
     *      Application Classes
     */

    inner class mLocationListener: LocationListener {

        override fun onLocationChanged(location: Location?) {
            if (location != null) {
                mLocation = location
                latitude = location.latitude
                longitude = location.longitude
                locationGrabbed = true
            }
            else {
                locationGrabbed = false
            }
        }

        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

        override fun onProviderEnabled(provider: String?) {}

        override fun onProviderDisabled(provider: String?) {}

    }

    inner class MainViewHolder(view: View) {
        val titleFrameLayout = view.findViewById<FrameLayout>(R.id.tipexperience_title_component)
        val contentFrameLayout = view.findViewById<FrameLayout>(R.id.tipexperience_content)
        val bottomFrameLayout = view.findViewById<FrameLayout>(R.id.tipexperience_bottom_component)

        fun setTitleView() {
            val toAdd = View.inflate(this@ExperienceController, R.layout.fragment_title_component, null)
            titleFrameLayout.addView(toAdd)
        }

        fun setContentView(view: View) {
            contentFrameLayout.addView(view)
        }

        fun setBottomView(view: View) {
            bottomFrameLayout.addView(view)
        }

    }

    inner class StartHolder(view: View) {
        private val date : TextView = view.findViewById<TextView>(R.id.textView_setDate)
        private val location : TextView = view.findViewById<TextView>(R.id.textView_setLocation)
        private val instructionsButton: Button = view.findViewById<Button>(R.id.button_instruction)

        init {
            instructionsButton.setOnClickListener {
                val builder = AlertDialog.Builder(this@ExperienceController)
                builder.setMessage("HOW TO GET AROUND:\n - Swipe right to progress to the next Category. \n - Swipe left to return to the previous Category.")
                builder.setTitle("Instructions")
                builder.setPositiveButton("Got It") {dialog, which -> dialog.dismiss()}
                builder.show()
            }
        }

        fun setDate(cal: Calendar) {
            date.text = dateToString(cal)
        }

        fun setLocation(b: Boolean) {
            if (b) { location.text = "YES" }
            else { location.text = "NO" }
        }
    }

    inner class CategoryHolder(view: View) {
        private val title: TextView = view.findViewById<TextView>(R.id.tv_title)
        private val image: ImageButton = view.findViewById<ImageButton>(R.id.iv_category_icon)
        val score: RadioGroup = view.findViewById(R.id.score)
        val c1: RadioButton = view.findViewById(R.id.checkbox_1)
        val c2: RadioButton = view.findViewById(R.id.checkbox_2)
        val c3: RadioButton = view.findViewById(R.id.checkbox_3)
        val c4: RadioButton = view.findViewById(R.id.checkbox_4)
        val c5: RadioButton = view.findViewById(R.id.checkbox_5)

        fun setTitle(str: String) {
            title.text = str
        }

        fun setImage(d : Drawable) {
            image.background = d
        }

        fun setChecks(i: Int) {
            when (i) {
                1 -> {
                    c1.isChecked = true
                }
                2 -> {
                    c2.isChecked = true
                }
                3 -> {
                    c3.isChecked = true
                }
                4 -> {
                    c4.isChecked = true
                }
                5 -> {
                    c5.isChecked = true
                }
                else -> {}
            }
        }

    }

    inner class EndCategoriesHolder(view: View) {
        private val tipPercent: TextView = view.findViewById(R.id.textview_display_tip_percent)
        val mealCost: EditText = view.findViewById(R.id.editText_mealCost)

        fun setTipPercent(d: Double) {
            val p = (d * 100).toInt()
            tipPercent.text = "%$p"
        }

    }

    inner class ReciptHolder(view: View) {
        private val address: TextView = view.findViewById(R.id.textView_displayAddress)
        private val date: TextView = view.findViewById(R.id.textView_display_date)
        private val subTotal: TextView = view.findViewById(R.id.textView_display_Sub_total)
        private val tipValue: TextView = view.findViewById(R.id.textView_display_tipvalue)
        private val finalTotal: TextView = view.findViewById(R.id.textView_display_total)

        fun setAddress(str: String) {
            address.text = str
        }

        fun setDate(cal: Calendar) {
            date.text = dateToString(cal)
        }

        fun setSubTotal(st: Double) {
//            subTotal.text = String.format("$%.2f", st)
            subTotal.text = "$%.2f".format(st)
        }

        fun setTipValue(tv: Double) {
//            tipValue.text = String.format("$%.2f", tv)
            tipValue.text = "$%.2f".format(tv)
        }

        fun setFinalCost(fc: Double) {
//            finalTotal.text = String.format("$%.2f", fc)
            finalTotal.text = "$%.2f".format(fc)
        }
    }

    inner class ProgressHolder(view: View) {
        private val progress: ProgressBar = view.findViewById(R.id.progressBar)
        private val runningTipPercent: TextView = view.findViewById(R.id.textView_currentTipPercent)

        fun setProgress(cc: Int) {
            progress.progress = cc
        }

        fun setRunningTipPercent(d: Double) {
            val p: Int = (d * 100).toInt()
            //runningTipPercent.text = String.format("%%d", p)
            runningTipPercent.text = "%$p"
        }

        fun setRunningScore(num: Int, den: Int) {
            val n = den * den
            runningTipPercent.text = "$num out of $n"
        }

    }

    inner class ButtonHolder(view: View) {
        val button: Button = view.findViewById(R.id.tipexperience_bottom_button)
    }



    companion object {
        val start = Category("Start")
        val finish = Category("Finish")
        val receipt = Category("Receipt")
        var cat1 = Category("Speed")
        var cat2 = Category("Accuracy")
        var cat3 = Category("Humor")
        var cat4 = Category("Politeness")
        var cat5 = Category("Food")
        const val decimalFormat = "$ %.2f"
        const val percentFormat = "% %d"
    }

}
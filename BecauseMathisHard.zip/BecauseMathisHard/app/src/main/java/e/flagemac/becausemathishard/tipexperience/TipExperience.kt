package e.flagemac.becausemathishard.tipexperience

import android.content.Intent
import android.location.Location
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import e.flagemac.becausemathishard.dataclasses.Tip
import java.util.*

/**
 *   need to use this to call a bunch of different Category Activities
 */
class TipExperience : AppCompatActivity() {

    var list: ArrayList<Category> = ArrayList()
    var currentPos = 0

    var date : Date? = null
    var location: Location = Location("")

    var scores : ArrayList<Int> = ArrayList()

    var result : Result? = null

    var defaultTip = 0.20
    var newTip = 0.20

    var mealcost = 0.0
    var totalcost = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (resultCode) {

            RESULT_START -> {
                if (data != null) {
                    location.latitude = data.extras.getDouble("latitude")
                    location.longitude = data.extras.getDouble("longitude")

                    val y = data.extras.getInt("year")
                    val m = data.extras.getInt("month")
                    val d = data.extras.getInt("day")

                    date = Date(y,m,d)

                }
            }

            RESULT_CATEGORY -> {
                currentPos++
                if (data != null) {
                    var hold = data.extras.getInt("score")
                    scores.add(hold)
                }
            }

            RESULT_FINISH -> {
                if (data != null) {
                    mealcost = data.extras.getDouble("meal_cost")
                    totalcost = data.extras.getDouble("meal_cost_final")
                }

                //Tip(mealcost, newTip, date!!, location)

                TODO("need to save this tip to a database")

            }
        }
    }

    private fun tipProcess(current : Int) : Boolean {

        if (current > list.size) {

            when (current) {
                0 -> list[current].setType(0)
                list.size - 1 -> list[current].setType(2)
                else -> list[current].setType(1)
            }

            val intent = Intent(this@TipExperience, ExperienceController()::class.java)

            if (list[current].t == Type.FINISH) {
                intent.putExtra("tip", newTip)
            }

            startActivityForResult(intent, REQUEST_CODE)

            return true
        }

        else { return false }

    }

    private fun tipProcess() {

        var count = 0

        for (cat in list) {

            when (count) {
                0 -> cat.setType(0)
                list.size - 1 -> cat.setType(2)
                else -> cat.setType(1)
            }

            val intent = Intent(this@TipExperience, ExperienceController()::class.java)

            if (cat.t == Type.FINISH) {
                intent.putExtra("tip", newTip)

            }

            startActivityForResult(intent, REQUEST_CODE)
        }
    }

    private fun getTotal(){
        var total = 0
        var count = 1

        for (x in scores) {
            total += x
            count++
        }

        when (total / count) {
            0 -> result = Result.SHIT
            1 -> result = Result.MEH
            2 -> result = Result.OKAY
            3 -> result = Result.GOOD
            4 -> result = Result.GREAT
            else -> result = Result.GOOD
        }
    }

    private fun newTipValue(){
        when (result) {
            Result.SHIT     -> {newTip = defaultTip - 0.15}
            Result.MEH      -> {newTip = defaultTip - 0.1}
            Result.OKAY     -> {newTip = defaultTip - 0.05}
            Result.GOOD     -> {newTip = defaultTip}
            Result.GREAT    -> {newTip = defaultTip + 0.05}
        }
    }

    companion object {
        private const val REQUEST_CODE = 100
        private const val RESULT_START = 101
        private const val RESULT_CATEGORY = 102
        private const val RESULT_FINISH = 103
    }
}

enum class Result {
    SHIT, MEH, OKAY, GOOD, GREAT
}

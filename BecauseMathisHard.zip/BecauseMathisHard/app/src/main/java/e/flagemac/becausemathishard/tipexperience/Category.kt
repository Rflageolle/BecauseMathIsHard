package e.flagemac.becausemathishard.tipexperience

import android.support.v7.widget.DialogTitle

/**
 * Created by FlageMac on 5/1/18.
 */
class Category(val title: String) {

    var t: Type? = null


    init{
        when(true) {
            title.equals("Start") -> {
                t = Type.START
            }

            title.equals("Finish") -> {
                t = Type.FINISH
            }

            title.equals("Receipt") -> {
                t = Type.RECEIPT
            }

            else -> {
                t = Type.CATEGORY
            }
        }
    }
    fun setType(pos: Int) {
        when (pos) {
            0 -> t = Type.START
            1 -> t = Type.CATEGORY
            2 -> t = Type.FINISH
            3 -> t = Type.RECEIPT
        }
    }

}

enum class Type {
    START, CATEGORY, FINISH, RECEIPT
}

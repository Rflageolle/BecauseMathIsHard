package e.flagemac.becausemathishard.dataclasses

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.Ignore
import android.arch.persistence.room.PrimaryKey
import android.location.Location
import java.sql.Date
import java.util.*


/**
 *   This simple data class will be the basis for persistance as well as the recall functions
 *   available to the user.
 */
@Entity(tableName = "tips")
data class Tip(
        @PrimaryKey(autoGenerate = true)
        val uid: Int,

        @ColumnInfo(name = "subtotal")
        val price: Double,

        @ColumnInfo(name = "percent")
        val tip: Double,

        @ColumnInfo(name = "date")
        val date: Long,

        @ColumnInfo(name = "longitude")
        var longitude: Double,

        @ColumnInfo(name = "latitude")
        var latitude: Double) {

    @Ignore
    constructor(id: Int, price: Double, tip: Double, cal: Calendar, location: Location) : this(id, price, tip, date = cal.time.time, longitude = location.longitude, latitude = location.latitude)

    private fun getFcost() : Double{
        return price * tip
    }

    fun tip_valueToString() : String {
        val tip_value = price * tip
        return "$ $tip_value"
    }

    fun fCostToString() : String {
        val tip_value = price * tip
        val fCost = price + (tip_value)
        return "$ $fCost"
    }

    fun priceToString() : String {
        return "$ $price"
    }

    fun tipToString() : String {
        val hold = (tip * 100).toInt()
        return "% $hold"
    }

    fun dateToString() : String {
        val cal: Calendar = Calendar.getInstance()
        cal.timeInMillis = date

        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH)
        val d = cal.get(Calendar.DAY_OF_MONTH)

        return String.format("%d/%d/%d", m, d, y)
    }

    fun locationToString() : String {
        return ("Lat: $latitude, Long: $longitude")
    }

    override fun toString(): String {
        return ("$date --->  Price: $price   Tip: $tip     Paid: ${getFcost()}")
    }

}
package e.flagemac.becausemathishard.dataclasses

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Delete
import android.arch.persistence.room.Insert
import android.arch.persistence.room.OnConflictStrategy.REPLACE
import android.arch.persistence.room.Query


@Dao
interface TipDAO {

    @Query("select * from tips")
    fun getAllTips(): List<Tip>

    @Query("select * from tips where uid = :id")
    fun findTipById(id: Long): Tip

    @Query("delete from tips")
    fun deleteAll()

    @Insert(onConflict = REPLACE)
    fun insertTip(tip: Tip)

    @Delete
    fun deleteTip(tip: Tip)

}
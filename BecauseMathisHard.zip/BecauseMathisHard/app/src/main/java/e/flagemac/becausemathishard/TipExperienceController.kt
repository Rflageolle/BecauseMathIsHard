package e.flagemac.becausemathishard

import android.animation.LayoutTransition
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.support.transition.AutoTransition
import android.support.transition.TransitionManager
import android.support.v4.app.ActivityCompat
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.animation.TranslateAnimation
import android.widget.*
import e.flagemac.becausemathishard.dataclasses.Tip
import e.flagemac.becausemathishard.tipexperience.ActivitySwipeDetector
import e.flagemac.becausemathishard.tipexperience.Category
import e.flagemac.becausemathishard.tipexperience.SwipeInterface
import e.flagemac.becausemathishard.tipexperience.Type
import java.text.Format
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by FlageMac on 5/2/18.
 */
class TipExperienceController : AppCompatActivity(), SwipeInterface, LayoutTransition.TransitionListener {

    var categories = 5
    var list : Array<Category> = arrayOf(start, cat1, cat2, cat3, cat4, cat5, finish)
    var categoryObjects : ArrayList<Objects> = ArrayList()
    var currentCategory = 0  // first Category

    var currentView: View? = null
    var swipeLayout : RelativeLayout? = null

    var scores : ArrayList<Int> = ArrayList()
    var total = {
        var hold = 0
        for (x in scores) {
            hold += x
        }
        hold
    }

    var baseTip = 0.20
    var tipToUse = 0.20
    var priceOfMeal = 0.0
    var tipValue = priceOfMeal * tipToUse
    var finalCost = priceOfMeal + tipValue

    var startFlag = false
    var categoryFlag = false
    var finishFlag = false
    var textFinishedFlag = false
    var useLocationFlag = true

    // variables for start fragment
        var date: Calendar? = null
        var mLocation: Location? = null
        var latitude : Double? = null
        var longitude : Double? = null

    /**
     *  ------------------------------  ___________________________________________________________
     *  ACTIVITY LIFECYLE - FUNCTIONS | -----------------------------------------------------------
     *  ------------------------------
     */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_good_tip)


        currentCategory = 0
        swipeLayout = this.findViewById<RelativeLayout>(R.id.swipe_layout)
        getLocation(this@TipExperienceController)

        val toAdd = View.inflate(this, setView(list[0]), null)
        val swipeInterface = ActivitySwipeDetector(this, this)

        currentView = toAdd
        swipeLayout!!.addView(toAdd)
        swipeLayout!!.setOnTouchListener(swipeInterface)

    }

    override fun onStart() {
        super.onStart()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    /**
     *  -------------------------  ________________________________________________________________
     *  END LIFECYCLE FUNCTIONS  | ----------------------------------------------------------------
     *  -------------------------
     */


    // SUPPORT FUNCTIONS -----------------------------------------------------------

    // Swipe Interface Methods
    override fun right2left(v: View) {
        when (v.id) {
            R.id.swipe_layout -> {
                // display previous Category
                val swipe_layout = this.findViewById<RelativeLayout>(R.id.swipe_layout)
                val transition = AutoTransition()
                transition.duration = 1000

                if (currentCategory < 8) {
                    currentCategory++

                    val toAdd =  View.inflate(this, setView(list[currentCategory]), null)
                    currentView = toAdd
                    swipe_layout.addView(toAdd)

                    setUpView(list[currentCategory])
                }
            }
        }
    }

    override fun left2right(v: View) {
        when (v.id) {
            R.id.swipe_layout -> {
                // display previous Category
                val swipe_layout = this.findViewById<RelativeLayout>(R.id.swipe_layout)
                val transition = AutoTransition()
                transition.duration = 1000

                // if no score toast to tell them it is needed

                    if (currentCategory > 0) {
                        currentCategory--


                        val toAdd =  View.inflate(this, setView(list[currentCategory]), null)
                        currentView = toAdd
                        swipe_layout.addView(toAdd)

                        setUpView(list[currentCategory])

                    }


            }
        }
    }

    // Transition Methods
    override fun startTransition(transition: LayoutTransition?, container: ViewGroup?, view: View?, transitionType: Int) {

    }

    override fun endTransition(transition: LayoutTransition?, container: ViewGroup?, view: View?, transitionType: Int) {

    }

    fun getLocation(c: Context) {
        val locationManager = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val enabledGPS = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val enabledWIFI = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        val criteria = Criteria()
        criteria.accuracy = Criteria.ACCURACY_FINE
        criteria.horizontalAccuracy = Criteria.ACCURACY_HIGH
        criteria.verticalAccuracy = Criteria.ACCURACY_HIGH
        criteria.isSpeedRequired = false
        criteria.isCostAllowed = true
        criteria.isBearingRequired = false
        val provider = locationManager.getBestProvider(criteria, false)
        var location: Location? = null


        if (checkPermissions()) {
            try {
                locationManager.requestSingleUpdate(provider, mLocationListener(), null)
            } catch (ex: SecurityException) {
                Toast.makeText(this@TipExperienceController, "${ex.toString()} + is why it aint working", Toast.LENGTH_LONG).show()
            }
        }

        else {
            val builder = AlertDialog.Builder(this@TipExperienceController)
            builder.setMessage("Would you like to change Location Permission?")
            builder.setTitle("ALLOW LOCATION!")
            builder.setPositiveButton("YES") { dialog, which ->
                useLocationFlag = true
                val locationIntent = Intent()
                locationIntent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                val uri = Uri.fromParts("package", packageName, null)
                startActivity(locationIntent)
            }
            builder.setNegativeButton("NO") { dialog, which ->
                useLocationFlag = false
                dialog!!.dismiss()
            }
            builder.create()
        }
    }

    fun checkPermissions() : Boolean {
        val permissionState = ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
        return permissionState == PackageManager.PERMISSION_GRANTED
    }

    private fun setView(c: Category) : Int {
        return when (c.t) {
            Type.START -> R.layout.fragment_infoscreen
            Type.FINISH -> R.layout.fragment_get_meal_cost
            Type.RECEIPT -> R.layout.fragement_recipt
            else -> R.layout.fragment_category
        }
    }

    private fun setUpView(c: Category) {
        when (c.t) {
            Type.START -> {
                startFlag = true
                val sh = StartHolder(currentView!!)
                sh.dateView.text = sh.dateToString()
                if (mLocation != null) {
                    sh.locationView.text = "$latitude!! , $longitude!!"
                }
            }

            Type.FINISH -> {
                val fh = GetMealCostHolder(currentView!!)
//                fh.button.setOnClickListener {
//                    try {
//                        val toD = fh.subTotalEdit.toString()
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//
//                    if (toD.isEmpty()) {
//                        Toast.makeText(this@TipExperienceController, "Enter Meal Sub-Total", Toast.LENGTH_LONG).show()
//                    }
//                    else {
//                        val subTotal = toD.toDouble()
//                        if (subTotal < 0) {
//                            Toast.makeText(this@TipExperienceController, "Negative prices do not exist", Toast.LENGTH_LONG).show()
//                        }
//                        else{
//                            priceOfMeal = 210.15
//
//                            currentCategory++
//
//                            val toAdd =  View.inflate(this, setView(list[currentCategory]), null)
//                            currentView = toAdd
//                            swipeLayout!!.addView(toAdd)
//
//                            setUpView(list[currentCategory])
//                        }
//                    }
//                }
            }

//            Type.FINISH -> {
//                finishFlag = true
//                val fh = FinishHolder(currentView!!)
//                fh.tipPercentView.text = String.format("%%d", (tipToUse * 100).toInt())//percentFormat.format((tipToUse * 100))
//
//                fh.userInput.addTextChangedListener(object : TextWatcher{
//                    override fun afterTextChanged(s: Editable?) {
//                        try {
//                            val d = s.toString().toDouble()
//                            if (d < 0) {
//                                Toast.makeText(this@TipExperienceController, "Positive numbers only", Toast.LENGTH_LONG).show()
//                            }
//                            else {
//                                priceOfMeal = d
//                                fh.priceView.text = decimalFormat.format(priceOfMeal)
//                                fh.tipPriceView.text = decimalFormat.format(tipValue)
//                            }
//                        } catch (npe : NullPointerException) {
//                            Toast.makeText(this@TipExperienceController, "Enter only numbers or period.", Toast.LENGTH_LONG).show()
//                        }
//                    }
//
//                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
//
//                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
//
//                })
//
//            }

            Type.RECEIPT -> {
                val rh = ReceiptHolder(currentView!!)
                rh.setDate(date!!)
                rh.setSubTotal(priceOfMeal)
                rh.setTipValue(tipValue)
                rh.setTotal(finalCost)

//                rh.finishButton.setOnClickListener {
//                    // Set new Location
//                    Tip(priceOfMeal, tipToUse, Date(2018,5,3), Location(""))
//
//                    super.finish()
//                }
            }
            else -> {
                categoryFlag = true
                val ch = CategoryHolder(currentView!!)
                ch.imageView.setImageDrawable(setImage(list[currentCategory]))
                ch.titleView.text = list[currentCategory].title
                ch.getScore()
            }
        }
    }

    private fun setImage(cat: Category) : Drawable {

        val d: Drawable

        when (cat.title) {

            "Speed" -> {
                d = getDrawable(R.drawable.speed_icon)
            }
            "Accuracy" -> {
                d = getDrawable(R.drawable.accuracy_icon)
            }
            "Humor" -> {
                d = getDrawable(R.drawable.humor_icon)
            }
            "Food" -> {
                d = getDrawable(R.drawable.food_icon)
            }
            "Politeness" -> {
                d = getDrawable(R.drawable.politness_icon)
            }

            else -> {
                d = getDrawable(R.drawable.ic_menu_gallery)
            }

        }

        return d
    }

    private fun processCategory() {
        for ((count, x) in list.withIndex()) {
            when (count) {
                0 -> {
                    x.setType(0)
                }
                list.size - 1 -> {
                    x.setType(2)
                }
                else -> {
                    x.setType(1)
                }
            }
        }
    }

    // END SUPPORT FUNCTIONS -------------------------------------------------------


    // SUPPORT CLASSES -------------------------------------------------------------

    inner class StartHolder(view: View) {
        val dateView: TextView = view.findViewById(R.id.textView_setDate) as TextView
        val locationView : TextView = view.findViewById(R.id.textView_setLocation) as TextView
        val useLocation : CheckBox = view.findViewById(R.id.checkbox_uselocation) as CheckBox

        init {
            dateView.text = dateToString()
        }

        fun dateToString() : String {
            val cal = Calendar.getInstance()
            val sdf = SimpleDateFormat("EEE, d MMM yyyy -- hh:mm")
            return sdf.format(cal)
        }

    }

    class CategoryHolder(view: View) {
        val titleView: TextView = view.findViewById(R.id.tv_title) as TextView
        val imageView: ImageView = view.findViewById(R.id.iv_category_icon) as ImageView
        var scr = 0
        private val val1 : CheckBox = view.findViewById(R.id.checkbox_1) as CheckBox
        private val val2 : CheckBox = view.findViewById(R.id.checkbox_2) as CheckBox
        private val val3 : CheckBox = view.findViewById(R.id.checkbox_3) as CheckBox
        private val val4 : CheckBox = view.findViewById(R.id.checkbox_4) as CheckBox
        private val val5 : CheckBox = view.findViewById(R.id.checkbox_5) as CheckBox

        init {
            val1.setOnClickListener {
                when (true) {
                    val1.isChecked -> {
                        val1.isChecked = false
                        scr = 0
                    }
                    val2.isChecked -> val2.isChecked = false
                    val3.isChecked -> val3.isChecked = false
                    val4.isChecked -> val4.isChecked = false
                    val5.isChecked -> val5.isChecked = false
                    !val1.isChecked -> scr = 1
                }
            }
            val2.setOnClickListener {
                when (true) {
                    val2.isChecked -> {
                        val2.isChecked = false
                        scr = 0
                    }
                    val1.isChecked -> val1.isChecked = false
                    val3.isChecked -> val3.isChecked = false
                    val4.isChecked -> val4.isChecked = false
                    val5.isChecked -> val5.isChecked = false
                    !val2.isChecked -> scr = 2
                }
            }
            val3.setOnClickListener {
                when (true) {
                    val3.isChecked -> {
                        val1.isChecked = false
                        scr = 0
                    }
                    val1.isChecked -> val1.isChecked = false
                    val2.isChecked -> val2.isChecked = false
                    val4.isChecked -> val4.isChecked = false
                    val5.isChecked -> val5.isChecked = false
                    !val3.isChecked -> scr = 3
                }
            }
            val4.setOnClickListener {
                when (true) {
                    val4.isChecked -> {
                        val1.isChecked = false
                        scr = 0
                    }
                    val1.isChecked -> val1.isChecked = false
                    val2.isChecked -> val2.isChecked = false
                    val3.isChecked -> val3.isChecked = false
                    val5.isChecked -> val5.isChecked = false
                    !val4.isChecked -> scr = 1
                }
            }
            val5.setOnClickListener {
                when (true) {
                    val5.isChecked -> {
                        val1.isChecked = false
                        scr = 0
                    }
                    val1.isChecked -> val1.isChecked = false
                    val2.isChecked -> val2.isChecked = false
                    val3.isChecked -> val3.isChecked = false
                    val4.isChecked -> val4.isChecked = false
                    !val5.isChecked -> scr = 5
                }
            }

        }

        fun getScore() : Int {
            return when (true) {
                val1.isChecked -> {1}
                val2.isChecked -> {2}
                val3.isChecked -> {3}
                val4.isChecked -> {4}
                val5.isChecked -> {5}
                else -> {0}
            }
        }

    }

    class FinishHolder(view: View) {
        val tipPercentView : TextView = view.findViewById(R.id.textView_final_tip_percent) as TextView
        val tipPriceView: TextView = view.findViewById(R.id.textView_displayTip) as TextView
        val priceView: TextView = view.findViewById(R.id.textView_displayCost) as TextView
        val userInput: EditText = view.findViewById(R.id.editText_mealCost) as EditText
    }

    class GetMealCostHolder(view: View) {
        val subTotalEdit : EditText = view.findViewById(R.id.editText_mealCost) as EditText
    }

    class ReceiptHolder(view: View) {
        val dateView: TextView = view.findViewById(R.id.textView_display_date) as TextView
        val subTotalView : TextView = view.findViewById(R.id.textView_display_Sub_total) as TextView
        val tipValueView : TextView = view.findViewById(R.id.textView_display_tipvalue) as TextView
        val totalView : TextView = view.findViewById(R.id.textView_display_total) as TextView

        fun setDate(date: Calendar) {
            val sdf = SimpleDateFormat("dd / MM / yyyy")
            dateView.text = sdf.format(date)
        }

        fun setSubTotal(subTotal: Double) {
            subTotalView.text = String.format("$%.2f", subTotal)
        }

        fun setTipValue(tipValue: Double) {
            tipValueView.text = String.format("$%.2f", tipValue)
        }

        fun setTotal(total: Double) {
            totalView.text = String.format("$%.2f", total)
        }
    }

    inner class mLocationListener: LocationListener {

        override fun onLocationChanged(location: Location?) {
            if (location != null) {
                mLocation = location
                latitude = location.latitude
                longitude = location.longitude
            }
            else {
                getLocation(this@TipExperienceController)
            }
        }

        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

        override fun onProviderEnabled(provider: String?) {}

        override fun onProviderDisabled(provider: String?) {}

    }

    // END SUPPORT CLASSES ---------------------------------------------------------



    companion object {
        val start = Category("Start")
        val finish = Category("Finish")
        val receipt = Category("Receipt")
        var cat1 = Category("Speed")
        var cat2 = Category("Accuracy")
        var cat3 = Category("Humor")
        var cat4 = Category("Politeness")
        var cat5 = Category("Food")
        const val decimalFormat = "$ %.2f"
        const val percentFormat = "% %d"
    }
}
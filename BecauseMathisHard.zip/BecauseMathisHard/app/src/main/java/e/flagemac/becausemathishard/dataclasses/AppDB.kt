package e.flagemac.becausemathishard.dataclasses

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase

@Database(entities = arrayOf(Tip::class), version = 1, exportSchema = false)
abstract class AppDB : RoomDatabase() {
    abstract fun tipDao() : TipDAO
}
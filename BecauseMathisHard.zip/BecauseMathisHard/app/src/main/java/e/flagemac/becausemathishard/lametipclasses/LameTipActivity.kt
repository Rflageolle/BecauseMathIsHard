package e.flagemac.becausemathishard.lametipclasses

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import e.flagemac.becausemathishard.R
import e.flagemac.becausemathishard.dataclasses.Tip
import kotlinx.android.synthetic.main.activity_lame_tip.*
import java.io.IOException
import java.util.*

class LameTipActivity : AppCompatActivity() {

    var costOfMeal = 0.0
    var tipPercent = 0.20   //  default

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lame_tip)

        // MARK:  Listeners
        edit_meal_cost.addTextChangedListener(object: TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s != null) {
                    try {
                        val temp = s.toString().toDouble()
                        costOfMeal = temp

                        if (edit_tip_perecentage != null) {
                            var tipPortion = costOfMeal * tipPercent
                            displayTipValue.text = String.format("$%.2f",tipPortion)
                            var finalCost = costOfMeal + tipPortion
                            displayFinalCost.text = String.format("$%.2f", finalCost)
                        }
                    }catch (e: IOException) {
                        Log.i("Meal Cost Error", e.toString())
                    }
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

        } )

        edit_tip_perecentage.addTextChangedListener(object: TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s != null) {
                    try {
                        val temp = s.toString().toDouble()
                        tipPercent = temp

                        if (edit_meal_cost != null) {
                            var tipPortion = costOfMeal * tipPercent
                            displayTipValue.text = String.format("$%.2f",tipPortion)
                            var finalCost = costOfMeal + tipPortion
                            displayFinalCost.text = String.format("$%.2f", finalCost)
                        }
                    }catch (e: IOException) {
                        Log.i("Meal Cost Error", e.toString())
                    }
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

        } )

        displayTipValue.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                when (true) {

                    (tipPercent - 0.20) > 0.0 -> {
                        val r = Random().nextInt()
                        when (true) {

                            (r / 3) > 0 -> {
                                dev_comments.text = positiveComment3
                            }

                            (r / 3) == 0 -> {
                                dev_comments.text = positiveComment2
                            }

                            (r / 3) < 0 -> {
                                dev_comments.text = positiveComment1
                            }
                        }
                    }

                    (tipPercent - 0.20) == 0.0 -> {
                        val r = Random().nextInt()

                        when (true) {

                            (r / 3) >= 0 -> {
                                dev_comments.text = okayComment1
                            }

                            (r / 3) < 0 -> {
                                dev_comments.text = okayComment2
                            }
                        }
                    }

                    (tipPercent - 0.20) < 0.0 -> {
                        val r = Random().nextInt()

                        when (true) {

                            (r / 3) > 0 -> {
                                dev_comments.text = negativeComment1
                            }

                            (r / 3) == 0 -> {
                                dev_comments.text = negativeComment2
                            }

                            (r / 3) < 0 -> {
                                dev_comments.text = negativeComment3
                            }
                        }
                    }
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

        })

        imageButton_information.setOnClickListener {
            // display instructions for Lame Tip Calc on dialog fragment

        }


        button_finish.setOnClickListener{
            Tip(1, costOfMeal, tipPercent, System.currentTimeMillis(), 0.0, 0.0)

            this.finish()
        }

    }

    companion object {
        private const val negativeComment1 = "Come on, They were that bad?"
        private const val negativeComment2 = "Really is that it?"
        private const val negativeComment3 = "Man that server must have been bad!"
        private const val okayComment1 = "Adequate, not great..."
        private const val okayComment2 = "Better than bad service."
        private const val positiveComment1 = "Yay, Good Service!"
        private const val positiveComment2 = "Good for you big spender!"
        private const val positiveComment3 = "They're gonna appreciate this!"
    }











}

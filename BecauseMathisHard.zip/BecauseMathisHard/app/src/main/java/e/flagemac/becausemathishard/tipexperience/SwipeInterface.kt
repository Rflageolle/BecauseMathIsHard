package e.flagemac.becausemathishard.tipexperience

import android.content.Context
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration

/**
 * Created by FlageMac on 5/2/18.
 */

class ActivitySwipeDetector(val cntxt: Context, private var activity: SwipeInterface) : View.OnTouchListener {

    private val logTag = "ACTIVITY: SWIPE DETECTOR"
    private val vc = ViewConfiguration.get(cntxt)
    private val dm = cntxt.resources.displayMetrics
    private val VELOCITY: Int = vc.scaledMinimumFlingVelocity
    private val MIN_DISTANCE = vc.scaledPagingTouchSlop * dm.density
    private val MAX_OFF_PATH = MIN_DISTANCE * 1.5
    private var timeDown : Long? = null
    private var timeUp : Long? = null
    private var downX : Float? = null
    private var downY: Float? = null
    private var upX: Float? = null
    private var upY: Float? = null

    fun onRightToLeftSwipe(v: View) {
        Log.i(logTag, "Swiped Right -> Left")
        activity.right2left(v)
    }

    fun onLeftToRightSwipe(v: View) {
        Log.i(logTag, "Swiped Left -> Right")
        activity.left2right(v)
    }

    override fun onTouch(v: View?, event: MotionEvent?): Boolean {
        when (event!!.action) {

            MotionEvent.ACTION_DOWN -> {
                Log.i(logTag, "ACTION_DOWN")
                timeDown = System.currentTimeMillis()
                downX = event.x
                downY = event.y
                return true
            }

            MotionEvent.ACTION_UP -> {
                Log.i(logTag, "ACTION_UP")
                timeUp = System.currentTimeMillis()

                upX = event.x
                upY = event.y

                val deltaX = (downX?.minus(upX!!))
                val absDeltaX = Math.abs(deltaX!!)
                val deltaY = (downY?.minus(upY!!))
                val absDeltaY = Math.abs(deltaY!!)

                val time = timeUp!!.minus(timeDown!!)


                if (absDeltaY > MAX_OFF_PATH) {
                    Log.i(logTag, String.format("absDeltaY =%.2f, MAX_OFF_PATH = %.2f", absDeltaY, MAX_OFF_PATH))
                    return v!!.performClick()
                }

                val M_SEC : Long = 1000
                if (absDeltaX > MIN_DISTANCE && absDeltaX > (time * VELOCITY / M_SEC)) {
                    if (deltaX < 0) { this.onLeftToRightSwipe(v!!)}
                    if (deltaX > 0) { this.onRightToLeftSwipe(v!!)}
                }
                else {
                    Log.i(logTag, String.format("absDeltaX = %.2f, MIN_DISTANCE = %.2f, absDeltaX > MIN_DISTANCE = %b", absDeltaX, MIN_DISTANCE, (absDeltaX > MIN_DISTANCE)))
                    Log.i(logTag, String.format("absDeltaX=%.2f, time=%d, VELOCITY=%d, time*VELOCITY/M_SEC=%d, absDeltaX > time * VELOCITY / M_SEC=%b", absDeltaX, time, VELOCITY, time * VELOCITY / M_SEC, (absDeltaX > time * VELOCITY / M_SEC)))
                    return v!!.performClick()
                }
            }

        }

        return false
    }

}

interface SwipeInterface  {

    public fun right2left(v: View) {}
    public fun left2right(v: View) {}

}
